# Person 1: Weather Feature

## Files to Commit

Copy these files to the project root maintaining the directory structure:

- `src/lib/weather.ts`
- `src/components/WeatherTile.tsx`
- `src/components/WeatherDisplay.tsx` (new file)
- `src/pages/MenuBoards.tsx`
- `.env` (if weather API keys are present)

## Commit Message

```
feat: Add weather display feature to kiosk and menu boards

- Implement weather API integration with WeatherAPI.com
- Add WeatherTile component for kiosk home page
- Add WeatherDisplay component for menu boards sidebar
- Integrate weather display into MenuBoards page
- Add environment variable for weather API key
```

## Dependencies

None - this is a standalone feature that can be committed independently.

## Commit Order

This can be committed at any time (no dependencies on other people's work).

## Instructions

1. Copy all files from this folder to the project root
2. If `.env` file exists, merge any weather API key entries with existing `.env` file
3. Stage and commit the files:
   ```bash
   git add src/lib/weather.ts src/components/WeatherTile.tsx src/components/WeatherDisplay.tsx src/pages/MenuBoards.tsx .env
   git commit -m "feat: Add weather display feature to kiosk and menu boards"
   ```

