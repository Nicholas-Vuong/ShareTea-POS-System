# Person 2: Checkout Flow & Receipt System

## Files to Commit

Copy these files to the project root maintaining the directory structure:

- `src/components/CartReview.tsx` (new file)
- `src/components/Checkout.tsx` (new file)
- `src/components/CashierReceipt.tsx` (new file)
- `src/components/KioskReceipt.tsx` (new file)

## Commit Message

```
feat: Implement checkout flow with payment and receipt components

- Add CartReview component for order review before checkout
- Add Checkout component with payment method selection and promo codes
- Add CashierReceipt component for cashier order completion
- Add KioskReceipt component for kiosk order confirmation
- Support multiple payment methods (cash, card, mobile)
- Implement promo code validation and discount calculation
```

## Dependencies

- Uses `cartStore` from Person 3 (should be committed first)
- Uses existing UI components (no conflicts)

## Commit Order

Should be committed **after** Person 3 (Cart Store) to ensure `cartStore` is available.

## Instructions

1. Copy all files from this folder to the project root
2. Stage and commit the files:
   ```bash
   git add src/components/CartReview.tsx src/components/Checkout.tsx src/components/CashierReceipt.tsx src/components/KioskReceipt.tsx
   git commit -m "feat: Implement checkout flow with payment and receipt components"
   ```

