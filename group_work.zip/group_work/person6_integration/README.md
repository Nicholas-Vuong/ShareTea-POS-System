# Person 6: Page Integrations & Checkout Flow

## Files to Commit

Copy these files to the project root maintaining the directory structure:

- `src/pages/Cashier.tsx`
- `src/pages/Kiosk.tsx`

## Commit Message

```
feat: Integrate checkout flow into Cashier and Kiosk pages

- Add multi-step checkout flow (cart review → checkout → receipt)
- Integrate CartReview, Checkout, and receipt components
- Add weather tile to Kiosk home page
- Implement order completion flow with receipt display
- Add navigation between checkout steps
- Support promo codes and payment method selection in order flow
```

## Dependencies

Requires the following to be committed first:
- Person 1 (Weather) - for WeatherTile in Kiosk
- Person 2 (Checkout) - for CartReview, Checkout, and receipt components
- Person 3 (Cart) - for cartStore
- Person 5 (API) - for createOrder API method

## Commit Order

Should be committed **last** (after Persons 1, 2, 3, and 5).

## Instructions

1. Copy all files from this folder to the project root
2. Stage and commit the files:
   ```bash
   git add src/pages/Cashier.tsx src/pages/Kiosk.tsx
   git commit -m "feat: Integrate checkout flow into Cashier and Kiosk pages"
   ```

