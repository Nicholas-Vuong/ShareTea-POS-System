# Person 5: API & Authentication Improvements

## Files to Commit

Copy these files to the project root maintaining the directory structure:

- `src/lib/api.ts`
- `src/pages/Login.tsx`
- `src/pages/Manager.tsx`

## Commit Message

```
feat: Enhance API with order creation and improve authentication

- Add createOrder API method with support for kiosk and cashier sources
- Implement promo code discount calculation in order creation
- Improve login to support both username and email authentication
- Add case-insensitive username matching for better UX
- Enhance Manager page with improved error handling
- Add support for payment method and promo code in orders
```

## Dependencies

None - API and authentication layer is independent.

## Commit Order

This can be committed at any time, but should be committed **before** Person 6 (Integration) since integration pages use the API.

## Instructions

1. Copy all files from this folder to the project root
2. Stage and commit the files:
   ```bash
   git add src/lib/api.ts src/pages/Login.tsx src/pages/Manager.tsx
   git commit -m "feat: Enhance API with order creation and improve authentication"
   ```

